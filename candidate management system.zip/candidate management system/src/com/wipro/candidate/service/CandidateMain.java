package com.wipro.candidate.service;

import java.util.ArrayList;


import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.dao.CandidateDAO;
import com.wipro.candidate.util.WrongDataException;

public class CandidateMain {

	/**
	 * @param args
	 */
	public String addCandidate(CandidateBean studBean)
	{
		String result="";
	    //write code here
		try {
			if(studBean==null || studBean.getName()==null ||studBean.getName().equals("")||studBean.getName().length()<2) {
				throw new WrongDataException();
			}
			if(studBean.getM1()<0||studBean.getM1()>100 || studBean.getM2()<0||studBean.getM2()>100 || studBean.getM3()<0||studBean.getM3>100)
				throw new WrongDataException();
		}catch(WrongDataException e) {
			return "Data Incorrect";
		}
		CandidateDAO a=new CandidateDAO();
		
		String id=a.generateCandidateId(studBean.getName());
		studBean.setId(id);
		String res="";
		String grade="";
		int m1=studBean.getM1();
		int m2=studBean.getM2();
		int m3=studBean.getM3();
		int tot=m1+m2+m3;
		if(tot>=240) {
			res="PASS";
			grade="Distinction";
		}else if(tot>=180&&tot<240) {
			res="PASS";
			grade="First Class";
		}else if(tot>=150&&tot<180) {
			res="PASS";
			grade="Second Class";
		}else if(tot>=105&&tot<150)
		{
			res="PASS";
			grade="Third Class";
		}else {
			res="FAIL";
			grade="No Grade";
		}
		studBean.setResult(res);
		studBean.setGrade(grade);
		String answer=a.addCandidate(studBean);
		if(answer.equals("SUCCESS")) {
			result=studBean.getId()+":"+studBean.getResult();
		}else {
			result="Error";
		}
	    return result;
		
	}
	public ArrayList<CandidateBean> displayAll(String criteria)
	{
		ArrayList<CandidateBean> res=null;
		if(criteria.equals("ALL")||criteria.equals("PASS")||criteria.equals("FAIL")) {
			CandidateDAO a=new CandidateDAO();
			res=a.getByResult(criteria);
		}
		return res;
		
		//write code here
		
	}
	public static void main(String[] args) {
		//write code here
		/*CandidateMain candidateMain=new CandidateMain();
		String result=candidateMain.addCandidate(null);
		System.out.println(result);*/
	}

}
