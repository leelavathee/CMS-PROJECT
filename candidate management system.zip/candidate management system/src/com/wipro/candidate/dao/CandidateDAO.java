package com.wipro.candidate.dao;


import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.DBUtil;

public class CandidateDAO {
	public String addCandidate(CandidateBean studentBean)
	{
			String status="";
			//write code here
			Connection con=DBUtil.getDBCon();
			try {  
				PreparedStatement p=con.prepareStatement("insert into CANDIDATE_TBL values(?,?,?,?,?,?,?)");
				p.setString(1,studentBean.getId());
				p.setString(2,studentBean.getName());
				p.setInt(3,studentBean.getM1());
				p.setInt(4,studentBean.getM2());
				p.setInt(5,studentBean.getM3());
				p.setString(6,studentBean.getResult());
				p.setString(7,studentBean.getGrade());
				
				boolean stat=p.execute();
				if(!stat) {
					status="SUCCESS";
				}else {
					status="FAIL";
				}
			}catch(SQLException e) {
				e.printStackTrace();
				status="FAIL";
			}
			return status;
	}
	public ArrayList<CandidateBean> getByResult(String criteria)
	{
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		//write code here
		Connection con=DBUtil.getDBConn(); 
		Statement s=null;
		ResultSet rs=null;
		
		try {
			s=con.createStatement();
			if(criteria.equals("ALL")) {
				rs=s.executeQuery("select *from CANDIDATE_TBL");
			}else {
				PreparedStatement ps=con.prepareStatement("select *from CANDIDATE_TBL where Result=?");
				ps.setString(1,criteria);
				rs=ps.executeQuery();
			}
			if(!rs.next()) {
				list=null;
			}else {
				while(rs.next()) {
					CandidateBean b=new CandidateBean();
					b.setId(rs.getString(1));
					b.setName(rs.getString(2));
					b.setM1(rs.getInt(3));
					b.setM2(rs.getInt(4));
					b.setM3(rs.getInt(5));
					b.setResult(rs.getString(6));
					b.setGrade(rs.getString(7));
					list.add(b);
					
				}
			}
		}
		catch(SQLException e) {
			System.out.println("exp");
			list=null;
		}
		return list;
	}
	public String generateCandidateId(String name)
	{
		String id="";
		//write code here
		String sn="";
		Connection con=DBUtil.getDBConn();
		try {
			Statement s=con.createStatement();
			ResultSet rs=s.executeQuery("select CANDID_SEQ.nextval from dual");
			while(rs.next()) {
				sn=rs.getString(1);
			}
			id=name.substring(0,2).toUpperCase()+sn;
				
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
}
